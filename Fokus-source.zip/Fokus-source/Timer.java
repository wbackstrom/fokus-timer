package se.fokus.intervaltimer;
import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
import org.json.*;
import java.util.Locale;

public class Timer extends BroadcastReceiver {
 static final int FLAGS=PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT;
 static SharedPreferences store(Context c){return c.getSharedPreferences("fokus",0);}
 static JSONObject json(String s){try{return new JSONObject(s);}catch(Exception e){return new JSONObject();}}
 static synchronized JSONObject state(Context c){return json(store(c).getString("state","{}"));}
 static PendingIntent open(Context c){return PendingIntent.getActivity(c,0,new Intent(c,Home.class),FLAGS);}
 static PendingIntent event(Context c,String action){return PendingIntent.getBroadcast(c,0,new Intent(c,Timer.class).setAction(action),FLAGS);}
 static int phase(int index,JSONArray cfg)throws JSONException{return index%2==0?0:((index+1)/2)%cfg.getInt(4)==0?2:1;}
 static synchronized void preferences(Context c,String s){
  if(s.equals(store(c).getString("prefs","")))return;
  store(c).edit().putString("prefs",s).commit();
  JSONObject st=state(c);if(st.has("config"))try{display(c,st);}catch(JSONException ignored){}
 }
 static synchronized void command(Context c,String action,String settings){
  try{
   JSONObject s=state(c);JSONArray cfg=s.optJSONArray("config");
   if(cfg==null||action.equals("start")){
    cfg=new JSONArray(settings);if(cfg.length()!=5)return;
    for(int i=0;i<5;i++)if(cfg.getInt(i)<1||cfg.getInt(i)>180)return;
   }
   int index=s.optInt("index");long end=s.optLong("end"),left=s.optLong("left",-1),now=System.currentTimeMillis();
   int last=2*cfg.getInt(3)-1;
   boolean changed=false;
   while(end>0&&end<=now&&index<last){index++;changed=true;end=index==last?0:end+60000L*cfg.getInt(phase(index,cfg));}
   if(action.equals("reset")){index=0;end=0;left=-1;}
   else if(action.equals("start")&&end==0&&left<0){index=0;end=now+cfg.getInt(0)*60000L;changed=true;}
   else if(action.equals("pause")&&end>0){left=end-now;end=0;}
   else if(action.equals("resume")&&left>=0){end=now+left;left=-1;}
   s.put("index",index).put("end",end).put("left",left).put("config",cfg);
   store(c).edit().putString("state",s.toString()).commit();
   AlarmManager alarms=c.getSystemService(AlarmManager.class);
   if(end>0)alarms.setAlarmClock(new AlarmManager.AlarmClockInfo(end,open(c)),event(c,"tick"));else alarms.cancel(event(c,"tick"));
   if(changed&&!action.equals("reset"))feedback(c,index==last?"done":index%2==0?"focus":"pause");
   display(c,s);
  }catch(JSONException ignored){}
 }
 static void feedback(Context c,String key){
  JSONObject prefs=json(store(c).getString("prefs","{}"));
  String tone=prefs.optString(key,"Ton");
  if(!"Tyst".equals(tone)){
   int res=tone.equals("Klang")?R.raw.chime:tone.equals("Dubbelton")?R.raw.two:R.raw.one;
   MediaPlayer mp=MediaPlayer.create(c,res,new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build(),0);
   if(mp!=null){mp.setOnCompletionListener(MediaPlayer::release);mp.start();}
  }
  c.getSystemService(Vibrator.class).vibrate(VibrationEffect.createOneShot(240,VibrationEffect.DEFAULT_AMPLITUDE),new VibrationAttributes.Builder().setUsage(VibrationAttributes.USAGE_ALARM).build());
 }
 static void display(Context c,JSONObject s)throws JSONException{
  NotificationManager nm=c.getSystemService(NotificationManager.class);
  long end=s.getLong("end"),left=s.getLong("left");int i=s.getInt("index");JSONArray cfg=s.getJSONArray("config");int total=cfg.getInt(3);boolean done=i>=2*total-1;
  if(end==0&&left<0&&!done){nm.cancel(1);return;}
  boolean en=json(store(c).getString("prefs","{}")).optString("language").equals("en");
  NotificationChannel channel=new NotificationChannel("clock","Fokus",NotificationManager.IMPORTANCE_LOW);channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);nm.createNotificationChannel(channel);
  String title=done?(en?"Session complete":"Omgång klar"):i%2==0?(en?"Focus ":"Fokus ")+(i/2+1)+(en?" of ":" av ")+total:phase(i,cfg)==1?(en?"Short break":"Kort paus"):(en?"Long break":"Lång paus");
  Notification.Builder b=new Notification.Builder(c,"clock").setContentTitle(title).setContentIntent(open(c)).setSmallIcon(R.drawable.mark).setVisibility(Notification.VISIBILITY_PUBLIC).setCategory(Notification.CATEGORY_ALARM).setOnlyAlertOnce(true).setOngoing(!done);
  if(Build.VERSION.SDK_INT>=36 && end>0)b.getExtras().putBoolean("android.requestPromotedOngoing",true);
  if(end>0)b.setWhen(end).setShowWhen(true).setUsesChronometer(true).setChronometerCountDown(true);
  if(left>=0){long sec=(left+999)/1000;b.setShowWhen(false).setContentText((en?"Paused · ":"Pausad · ")+String.format(Locale.ROOT,"%d:%02d",sec/60,sec%60));}
  if(!done)b.addAction(new Notification.Action.Builder(null,end>0?(en?"Pause":"Pausa"):(en?"Resume":"Fortsätt"),event(c,end>0?"pause":"resume")).build());
  nm.notify(1,b.build());
 }
 public void onReceive(Context c,Intent intent){command(c,intent.getAction(),"[]");}
}
