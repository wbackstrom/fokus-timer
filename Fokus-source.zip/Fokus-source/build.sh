#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
sdk=${ANDROID_HOME:?Set ANDROID_HOME}
bt="$sdk/build-tools/35.0.0"
platform="$sdk/platforms/android-36/android.jar"
mkdir -p build/{gen,classes,dex}
cd build
"$bt/aapt2" compile --dir ../res -o res.zip
"$bt/aapt2" link -o unsigned.apk -I "$platform" --manifest ../AndroidManifest.xml -A ../assets --java gen res.zip
javac --release 8 -classpath "$platform" -d classes gen/se/fokus/intervaltimer/R.java ../Home.java ../Timer.java ../Widget.java ../WidgetClock.java
jar cf code.jar -C classes .
"$bt/d8" --lib "$platform" --min-api 33 --output dex code.jar
(cd dex && zip -q ../unsigned.apk classes.dex)
"$bt/zipalign" -f 4 unsigned.apk aligned.apk
echo "Unsigned aligned APK: build/aligned.apk"
