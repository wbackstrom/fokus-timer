package se.fokus.intervaltimer;
import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.os.*;
import android.widget.RemoteViews;
import org.json.JSONObject;

public class WidgetClock extends Service {
 private final Handler handler=new Handler(Looper.getMainLooper());
 static boolean needed(Context c){
  return Timer.state(c).optLong("end")>0 && "matrix".equals(Timer.json(Timer.store(c).getString("prefs","{}")).optString("font","matrix"))
   && AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c,Widget.class)).length>0;
 }
 static void sync(Context c){
  Intent intent=new Intent(c,WidgetClock.class);
  if(needed(c)){try{c.startForegroundService(intent);}catch(ForegroundServiceStartNotAllowedException ignored){}}else c.stopService(intent);
 }
 private final Runnable tick=new Runnable(){public void run(){
  long remaining=Timer.state(WidgetClock.this).optLong("end")-System.currentTimeMillis();
  if(remaining<=0||!getSystemService(PowerManager.class).isInteractive())return;
  JSONObject prefs=Timer.json(Timer.store(WidgetClock.this).getString("prefs","{}"));
  RemoteViews v=new RemoteViews(getPackageName(),R.layout.widget_matrix);
  Widget.showTime(v,remaining,"light".equals(prefs.optString("palette"))?0xff171717:0xffeeeeee);
  AppWidgetManager m=AppWidgetManager.getInstance(WidgetClock.this);
  m.partiallyUpdateAppWidget(m.getAppWidgetIds(new ComponentName(WidgetClock.this,Widget.class)),v);
  handler.postDelayed(this,(remaining-1)%1000+1);
 }};
 private final BroadcastReceiver screen=new BroadcastReceiver(){public void onReceive(Context c,Intent i){handler.removeCallbacks(tick);tick.run();}};
 public void onCreate(){super.onCreate();IntentFilter f=new IntentFilter(Intent.ACTION_SCREEN_ON);f.addAction(Intent.ACTION_SCREEN_OFF);registerReceiver(screen,f);}
 public int onStartCommand(Intent i,int flags,int id){
  JSONObject s=Timer.state(this);
  try{startForeground(1,Timer.notification(this,s));}catch(Exception e){stopSelf();return START_NOT_STICKY;}
  if(!needed(this)){stopSelf();return START_NOT_STICKY;}
  handler.removeCallbacks(tick);tick.run();return START_STICKY;
 }
 public void onDestroy(){handler.removeCallbacks(tick);unregisterReceiver(screen);stopForeground(STOP_FOREGROUND_DETACH);super.onDestroy();}
 public IBinder onBind(Intent i){return null;}
}
