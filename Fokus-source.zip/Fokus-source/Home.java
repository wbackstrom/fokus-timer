package se.fokus.intervaltimer;
import android.app.*;
import android.os.*;
import android.webkit.*;
import android.content.pm.PackageManager;
import org.json.*;

public class Home extends Activity {
 WebView web;
 public void onCreate(Bundle state){
  super.onCreate(state);
  web=new WebView(this);web.setBackgroundColor(0xff000000);
  web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
  web.setWebChromeClient(new WebChromeClient());
  web.setWebViewClient(new WebViewClient(){public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){return true;}});
  web.addJavascriptInterface(new Bridge(),"Device");setContentView(web);web.loadUrl("file:///android_asset/Fokus.html");
  if(checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
   requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},1);
 }
 public void onBackPressed(){web.evaluateJavascript("document.getElementById('resetDialog').open ? 2 : (!document.getElementById('settings').hidden ? 1 : 0)",r->{if("2".equals(r))web.evaluateJavascript("resetDialog.close()",null);else if("1".equals(r))web.evaluateJavascript("settingsView(false)",null);else super.onBackPressed();});}
 class Bridge{
  @JavascriptInterface public String state(){return Timer.state(Home.this).toString();}
  @JavascriptInterface public void act(String action,String config){Timer.command(Home.this,action,config);}
  @JavascriptInterface public void preferences(String value){Timer.preferences(Home.this,value);}
 }
}
