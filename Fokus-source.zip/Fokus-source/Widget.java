package se.fokus.intervaltimer;
import android.appwidget.*;
import android.graphics.*;
import android.content.*;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;
import org.json.*;
import java.util.Locale;

public class Widget extends AppWidgetProvider {
 public void onUpdate(Context c,AppWidgetManager manager,int[] ids){refresh(c);WidgetClock.sync(c);}
 public void onDisabled(Context c){c.stopService(new Intent(c,WidgetClock.class));}
 static final String[] DIGITS={"01110 10001 10001 10001 10001 10001 01110","00100 01100 00100 00100 00100 00100 01110","01110 10001 00001 00010 00100 01000 11111","11110 00001 00001 01110 00001 00001 11110","00010 00110 01010 10010 11111 00010 00010","11111 10000 10000 11110 00001 00001 11110","01110 10000 10000 11110 10001 10001 01110","11111 00001 00010 00100 01000 01000 01000","01110 10001 10001 01110 10001 10001 01110","01110 10001 10001 01111 00001 00001 01110"};
 static void showTime(RemoteViews v,long millis,int ink){
  long sec=(Math.max(0,millis)+999)/1000;
  String time=String.format(Locale.ROOT,"%d:%02d",sec/60,sec%60);
  int step=12,cols=time.length()*6-5;
  Bitmap image=Bitmap.createBitmap(cols*step,7*step,Bitmap.Config.ARGB_8888);
  Canvas canvas=new Canvas(image);Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setColor(ink);
  int x=0;
  for(char ch:time.toCharArray()){
   String[] rows=(ch==':'?"0 0 1 0 1 0 0":DIGITS[ch-'0']).split(" ");
   for(int r=0;r<7;r++)for(int col=0;col<rows[r].length();col++)if(rows[r].charAt(col)=='1')
    canvas.drawCircle((x+col+.5f)*step,(r+.5f)*step,step*.38f,paint);
   x+=rows[0].length()+1;
  }
  v.setImageViewBitmap(R.id.timepicture,image);v.setContentDescription(R.id.timepicture,time);
 }
 static Bitmap lettering(Context c,String text,int ink,int size){
  Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
  paint.setTypeface(c.getResources().getFont(R.font.matrix));
  paint.setColor(ink);paint.setTextSize(size);
  Rect bounds=new Rect();paint.getTextBounds(text,0,text.length(),bounds);
  Bitmap image=Bitmap.createBitmap(Math.max(1,bounds.width()+8),Math.max(1,bounds.height()+8),Bitmap.Config.ARGB_8888);
  new Canvas(image).drawText(text,4-bounds.left,4-bounds.top,paint);
  return image;
 }
 static void refresh(Context c){
  AppWidgetManager manager=AppWidgetManager.getInstance(c);
  ComponentName provider=new ComponentName(c,Widget.class);
  if(manager.getAppWidgetIds(provider).length==0)return;
  JSONObject s=Timer.state(c), prefs=Timer.json(Timer.store(c).getString("prefs","{}"));
  boolean en="en".equals(prefs.optString("language"));
  int index=s.optInt("index");JSONArray cfg=s.optJSONArray("config");
  long end=s.optLong("end"),left=s.optLong("left",-1);
  boolean running=end>0;
  String label=en?"Focus":"Fokus",detail=en?"Ready":"Redo";
  if(running||left>=0){
   int total=cfg.optInt(3,4);
   if(index%2==0)label+=" "+(index/2+1)+(en?" of ":" av ")+total;
   else{
    boolean longer=((index+1)/2)%Math.max(1,cfg.optInt(4,4))==0;
    label=longer?(en?"Long break":"Lång paus"):(en?"Short break":"Kort paus");
   }
   if(!running){
    label+=(en?" · Paused":" · Pausad");
    long seconds=(left+999)/1000;
    detail=String.format(Locale.ROOT,"%d:%02d",seconds/60,seconds%60);
   }
  }else if(cfg!=null&&index>=2*cfg.optInt(3,4)-1){detail=en?"Complete":"Klar";}
  String face=prefs.optString("font","matrix");
  boolean matrix="matrix".equals(face);
  boolean light="light".equals(prefs.optString("palette"));
  int ink=light?0xff171717:0xffeeeeee;
  int layout=matrix?R.layout.widget_matrix:"system".equals(face)?R.layout.widget_system:R.layout.widget;
  RemoteViews v=new RemoteViews(c.getPackageName(),layout);
  v.setInt(R.id.card,"setBackgroundResource",light?R.drawable.widget_light:R.drawable.widget_bg);
  if(!matrix){v.setTextColor(R.id.phase,ink);v.setTextColor(R.id.remaining,ink);v.setTextColor(R.id.countdown,ink);}
  v.setImageViewResource(R.id.phaseicon,cfg!=null&&index>=2*cfg.optInt(3,4)-1?R.drawable.w_done:index%2==0?R.drawable.w_focus:R.drawable.w_break);
  v.setInt(R.id.phaseicon,"setColorFilter",ink);
  if(matrix){
   v.setImageViewBitmap(R.id.caption,lettering(c,label.toUpperCase(Locale.ROOT),ink,40));
   v.setContentDescription(R.id.caption,label);
   if(running||left>=0)showTime(v,running?end-System.currentTimeMillis():left,ink);
   else{v.setImageViewBitmap(R.id.timepicture,lettering(c,detail.toUpperCase(Locale.ROOT),ink,144));v.setContentDescription(R.id.timepicture,detail);}
  }else{
   v.setTextViewText(R.id.phase,label);
   v.setTextViewText(R.id.remaining,detail);
   v.setViewVisibility(R.id.remaining,running?View.GONE:View.VISIBLE);
  v.setViewVisibility(R.id.countdown,running?View.VISIBLE:View.GONE);
  v.setChronometerCountDown(R.id.countdown,true);
  v.setChronometer(R.id.countdown,SystemClock.elapsedRealtime()+Math.max(0,end-System.currentTimeMillis()),null,running);
  }
  String action=running?"pause":left>=0?"resume":"start";
  String button=running?(en?"Pause":"Pausa"):left>=0?(en?"Resume":"Fortsätt"):(en?"Start":"Starta");
  v.setTextViewText(R.id.control,button);v.setTextColor(R.id.control,ink);
  android.app.PendingIntent control=Timer.event(c,action);
  v.setInt(R.id.control,"setBackgroundResource",light?R.drawable.widget_action_light:R.drawable.widget_action_dark);
  v.setContentDescription(R.id.control,button);
  v.setOnClickPendingIntent(R.id.control,control);
  v.setOnClickPendingIntent(matrix?R.id.timepicture:running?R.id.countdown:R.id.remaining,control);
  v.setOnClickPendingIntent(R.id.card,Timer.open(c));
  manager.updateAppWidget(provider,v);
 }
}
